package moritz.prog1.exercises.set09;

public enum Algorithmus {
    BUBBLESORT, INSERTIONSORT, SELECTIONSORT
}
