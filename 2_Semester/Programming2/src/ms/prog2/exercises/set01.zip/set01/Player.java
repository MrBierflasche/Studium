package ms.prog2.exercises.set01;

public class Player {
    private final char symbol;
    public Player(char symbol) {
        this.symbol = symbol;
    }

    public char getSymbol() {
        return symbol;
    }
}
